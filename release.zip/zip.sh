#!/bin/bash

python3 zip.py
