# TORO-ResourcePack

TOROサーバーのリソースパック

## リソースパックのzipファイルの自動生成について

GitHub Actions を利用してリソースパックのzipファイルを自動生成しています。

`zip.py` リソースパックのzipファイルを自動で生成する。

`sha1.sh` リソースパックのzipファイルのsha1コードを出力する。
